import { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './reviews.css';

const topics = ['General experience', 'HTML', 'CSS', 'Java', 'Python', 'Web development', 'Other programming topic'];

function Stars({ rating, interactive = false, onSelect, selected = 0 }) {
  if (!interactive) {
    return <span className="stars" aria-label={`${rating} out of 5 stars`}>{'★'.repeat(rating)}<span>{'★'.repeat(5 - rating)}</span></span>;
  }

  return (
    <div className="rating-picker" role="radiogroup" aria-label="Choose a rating">
      {[1, 2, 3, 4, 5].map((value) => (
        <button
          aria-label={`${value} ${value === 1 ? 'star' : 'stars'}`}
          aria-checked={selected === value}
          className={value <= selected ? 'rating-star is-selected' : 'rating-star'}
          key={value}
          onClick={() => onSelect(value)}
          tabIndex={selected === value || (!selected && value === 1) ? 0 : -1}
          onKeyDown={(event) => {
            if (event.key === 'ArrowRight' || event.key === 'ArrowUp') {
              event.preventDefault();
              const next = Math.min(5, value + 1);
              onSelect(next);
              event.currentTarget.parentElement.children[next - 1].focus();
            }
            if (event.key === 'ArrowLeft' || event.key === 'ArrowDown') {
              event.preventDefault();
              const next = Math.max(1, value - 1);
              onSelect(next);
              event.currentTarget.parentElement.children[next - 1].focus();
            }
          }}
          role="radio"
          type="button"
        >★</button>
      ))}
      <span className="rating-hint">{selected ? `${selected} out of 5` : 'Select a rating'}</span>
    </div>
  );
}

function ReviewCard({ review }) {
  const date = new Date(review.createdAt);
  return (
    <article className="review-card">
      <div className="review-card__top">
        <div className="review-person">
          <span className="review-avatar" aria-hidden="true">{review.name.trim().charAt(0).toUpperCase()}</span>
          <div>
            <h4>{review.name}</h4>
            <p>{review.course || 'General experience'}</p>
          </div>
        </div>
        <time dateTime={date.toISOString()}>{date.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}</time>
      </div>
      <Stars rating={review.rating} />
      <p className="review-copy">{review.review}</p>
    </article>
  );
}

function App() {
  const [reviews, setReviews] = useState([]);
  const [sort, setSort] = useState('newest');
  const [rating, setRating] = useState(0);
  const [reviewText, setReviewText] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState(null);

  useEffect(() => {
    fetch('/api/reviews')
      .then((response) => {
        if (!response.ok) throw new Error('Reviews could not be loaded.');
        return response.json();
      })
      .then(setReviews)
      .catch((error) => setMessage({ type: 'error', text: error.message }))
      .finally(() => setLoading(false));
  }, []);

  const average = reviews.length
    ? (reviews.reduce((total, item) => total + item.rating, 0) / reviews.length).toFixed(1)
    : '—';
  const orderedReviews = [...reviews].sort((first, second) => {
    if (sort === 'highest') return second.rating - first.rating || second.createdAt - first.createdAt;
    if (sort === 'lowest') return first.rating - second.rating || second.createdAt - first.createdAt;
    return second.createdAt - first.createdAt;
  });

  async function handleSubmit(event) {
    event.preventDefault();
    setMessage(null);
    if (!rating) {
      setMessage({ type: 'error', text: 'Choose a star rating before submitting.' });
      return;
    }

    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    const payload = {
      name: form.get('name').trim(),
      course: form.get('course'),
      rating,
      review: reviewText.trim(),
    };

    setSubmitting(true);
    try {
      const response = await fetch('/api/reviews', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Your review could not be submitted.');
      setReviews((current) => [result, ...current]);
      setRating(0);
      setReviewText('');
      formElement.reset();
      setSort('newest');
      setMessage({ type: 'success', text: 'Thanks for sharing your experience.' });
    } catch (error) {
      setMessage({ type: 'error', text: error.message });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main className="page-shell">
      <header className="site-header">
        <a className="brand" href="https://next-programmers-6ffw.onrender.com/" aria-label="Next Programmers home">
          <img className="brand-logo" src="/logo.png" alt="" width="38" height="38" />
          <span>NEXT <strong>PROGRAMMERS</strong></span>
        </a>
        <a className="back-link" href="https://next-programmers-6ffw.onrender.com/">Back to learning <span aria-hidden="true">↗</span></a>
      </header>

      <section className="reviews-page" aria-labelledby="page-title">
        <div className="page-intro">
          <div className="intro-copy">
            <p className="eyebrow"><span className="status-dot" /> THE LEARNER COMMUNITY</p>
            <h1 id="page-title">Every next step<br /><span>starts somewhere.</span></h1>
            <p className="intro-description">Honest notes from people learning to build with code. Share what your journey has been like.</p>
          </div>
          <aside className="rating-overview" aria-label="Community rating">
            <p className="overview-label">LEARNER RATING</p>
            <div className="overview-score">{average}<span>/ 5</span></div>
            <Stars rating={Math.round(Number(average) || 0)} />
            <p className="overview-count">{reviews.length ? `Based on ${reviews.length} ${reviews.length === 1 ? 'review' : 'reviews'}` : 'No reviews yet'}</p>
          </aside>
        </div>

        <section className="community-section" aria-labelledby="reviews-title">
          <div className="section-heading">
            <div>
              <p className="eyebrow">FROM THE COMMUNITY</p>
              <h2 id="reviews-title">Learner stories <span className="heading-count">{reviews.length.toString().padStart(2, '0')}</span></h2>
            </div>
            <label className="sort-control">Sort by
              <select value={sort} onChange={(event) => setSort(event.target.value)}>
                <option value="newest">Most recent</option>
                <option value="highest">Highest rated</option>
                <option value="lowest">Lowest rated</option>
              </select>
            </label>
          </div>

          {loading ? (
            <div className="empty-state" aria-live="polite"><span className="loading-mark" aria-hidden="true">NP</span><p>Loading learner stories...</p></div>
          ) : orderedReviews.length ? (
            <div className="review-list" aria-live="polite">{orderedReviews.map((item) => <ReviewCard key={item.id} review={item} />)}</div>
          ) : (
            <div className="empty-state" aria-live="polite">
              <span className="empty-mark" aria-hidden="true">01</span>
              <div><h3>Start the conversation.</h3><p>There are no reviews just yet. Tell the next learner what you discovered.</p></div>
            </div>
          )}
        </section>

        <section className="write-section" aria-labelledby="write-title">
          <div className="write-heading">
            <p className="eyebrow"><span className="status-dot" /> YOUR TURN</p>
            <h2 id="write-title">Make your<br /><span>experience count.</span></h2>
            <p>What clicked? What would you change? Your feedback helps the next learner take their first step.</p>
            <div className="write-index"><span>NP</span><span>COMMUNITY / 01</span></div>
          </div>
          <form className="review-form" onSubmit={handleSubmit}>
            <div className="form-row">
              <label>Name to display<input autoComplete="nickname" maxLength="40" name="name" placeholder="e.g. CodeLearner" required /></label>
              <label>Course or topic<select defaultValue="General experience" name="course">{topics.map((topic) => <option key={topic}>{topic}</option>)}</select></label>
            </div>
            <fieldset className="rating-field">
              <legend>Your rating <span>Choose 1 to 5 stars</span></legend>
              <Stars interactive rating={rating} selected={rating} onSelect={setRating} />
            </fieldset>
            <label className="review-input-label">Your review
              <textarea maxLength="600" minLength="10" name="review" onChange={(event) => setReviewText(event.target.value)} placeholder="What was learning with Next Programmers like?" required rows="4" value={reviewText} />
              <span className="character-count">10–600 characters <span>{reviewText.length} / 600</span></span>
            </label>
            <div className="form-bottom">
              <p>Use a display name and keep personal details out of your review.</p>
              <button className="submit-button" disabled={submitting} type="submit">{submitting ? 'Sending...' : 'Submit review'} <span aria-hidden="true">↗</span></button>
            </div>
            {message && <p className={`form-message is-${message.type}`} role="status">{message.text}</p>}
          </form>
        </section>
        <footer className="page-footer"><span>CODE YOUR NEXT.</span><span>NEXT PROGRAMMERS <i>•</i> 2026</span></footer>
      </section>
    </main>
  );
}

createRoot(document.getElementById('root')).render(<App />);
