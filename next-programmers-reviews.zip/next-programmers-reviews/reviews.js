(() => {
  'use strict';
  const STORAGE_KEY = 'next-programmers-reviews-v1';
  const root = document.querySelector('#reviews.np-reviews');
  if (!root) return;

  const form = root.querySelector('#np-review-form');
  const nameInput = root.querySelector('#np-review-name');
  const courseInput = root.querySelector('#np-review-course');
  const reviewInput = root.querySelector('#np-review-text');
  const charCount = root.querySelector('#np-char-count');
  const message = root.querySelector('#np-form-message');
  const list = root.querySelector('#np-review-list');
  const sortSelect = root.querySelector('#np-review-sort');
  const average = root.querySelector('#np-average-rating');
  const summaryStars = root.querySelector('#np-summary-stars');
  const reviewCount = root.querySelector('#np-review-count');
  const ratingHint = root.querySelector('#np-rating-hint');
  const starButtons = [...root.querySelectorAll('.np-star-button')];
  let selectedRating = 0;
  let reviews = loadReviews();

  function loadReviews() {
    try {
      const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
      return Array.isArray(parsed) ? parsed.filter(isValidReview) : [];
    } catch (error) {
      return [];
    }
  }

  function isValidReview(item) {
    return item && typeof item.name === 'string' && typeof item.review === 'string' &&
      Number.isInteger(item.rating) && item.rating >= 1 && item.rating <= 5 &&
      item.name.length <= 40 && item.review.length >= 10 && item.review.length <= 600;
  }

  function saveReviews() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(reviews));
      return true;
    } catch (error) {
      return false;
    }
  }

  function setRating(value) {
    selectedRating = value;
    starButtons.forEach((button) => {
      const active = Number(button.dataset.rating) <= value;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-checked', String(Number(button.dataset.rating) === value));
      button.tabIndex = Number(button.dataset.rating) === value || (value === 0 && button.dataset.rating === '1') ? 0 : -1;
    });
    ratingHint.textContent = value ? `${value} out of 5 stars` : 'Select a rating';
  }

  function showMessage(text, type) {
    message.textContent = text;
    message.className = `np-form-message is-visible is-${type}`;
  }

  function renderSummary() {
    const total = reviews.length;
    if (!total) {
      average.textContent = '—';
      const suffix = document.createElement('span');
      suffix.textContent = '/ 5';
      average.appendChild(suffix);
      summaryStars.textContent = '☆☆☆☆☆';
      summaryStars.setAttribute('aria-label', 'No ratings yet');
      reviewCount.textContent = 'Be the first to leave a review.';
      return;
    }
    const mean = reviews.reduce((sum, item) => sum + item.rating, 0) / total;
    average.textContent = mean.toFixed(1);
    const suffix = document.createElement('span');
    suffix.textContent = '/ 5';
    average.appendChild(suffix);
    const rounded = Math.round(mean);
    summaryStars.textContent = '★'.repeat(rounded) + '☆'.repeat(5 - rounded);
    summaryStars.setAttribute('aria-label', `${mean.toFixed(1)} out of 5 stars`);
    reviewCount.textContent = `${total} ${total === 1 ? 'review' : 'reviews'} from this browser`;
  }

  function makeElement(tag, className, text) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined) element.textContent = text;
    return element;
  }

  function renderReviews() {
    list.replaceChildren();
    let shown = [...reviews];
    if (sortSelect.value === 'highest') shown.sort((a, b) => b.rating - a.rating || b.createdAt - a.createdAt);
    else if (sortSelect.value === 'lowest') shown.sort((a, b) => a.rating - b.rating || b.createdAt - a.createdAt);
    else shown.sort((a, b) => b.createdAt - a.createdAt);

    if (!shown.length) {
      const empty = makeElement('div', 'np-review-empty');
      empty.append(
        makeElement('div', 'np-review-empty__icon', '✦'),
        makeElement('h4', '', 'Your review could be the first'),
        makeElement('p', '', 'No reviews yet. Tell other learners what your experience has been like.')
      );
      list.appendChild(empty);
      return;
    }

    shown.forEach((item) => {
      const card = makeElement('article', 'np-review-card');
      const top = makeElement('div', 'np-review-card__top');
      const person = makeElement('div', 'np-review-card__person');
      const initial = item.name.trim().charAt(0).toUpperCase() || '?';
      person.append(
        makeElement('div', 'np-review-card__avatar', initial),
      );
      const details = makeElement('div');
      details.append(makeElement('div', 'np-review-card__name', item.name));
      details.append(makeElement('div', 'np-review-card__course', item.course || 'General experience'));
      person.appendChild(details);
      const date = makeElement('time', 'np-review-card__date');
      date.dateTime = new Date(item.createdAt).toISOString();
      date.textContent = new Date(item.createdAt).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
      top.append(person, date);
      const stars = makeElement('div', 'np-review-card__stars', '★'.repeat(item.rating) + '☆'.repeat(5 - item.rating));
      stars.setAttribute('aria-label', `${item.rating} out of 5 stars`);
      const body = makeElement('p', 'np-review-card__text', item.review);
      card.append(top, stars, body);
      list.appendChild(card);
    });
  }

  starButtons.forEach((button, index) => {
    button.addEventListener('click', () => setRating(Number(button.dataset.rating)));
    button.addEventListener('keydown', (event) => {
      if (event.key === 'ArrowRight' || event.key === 'ArrowUp') {
        event.preventDefault();
        const next = Math.min(5, selectedRating || 1 + index);
        setRating(Math.min(5, next + 1));
        starButtons[Math.min(4, next)].focus();
      } else if (event.key === 'ArrowLeft' || event.key === 'ArrowDown') {
        event.preventDefault();
        const next = Math.max(1, selectedRating || index + 1);
        setRating(Math.max(1, next - 1));
        starButtons[Math.max(0, next - 2)].focus();
      }
    });
  });

  reviewInput.addEventListener('input', () => {
    charCount.textContent = `${reviewInput.value.length} / 600`;
  });
  sortSelect.addEventListener('change', renderReviews);

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const name = nameInput.value.trim();
    const review = reviewInput.value.trim();
    if (name.length < 1 || name.length > 40) return showMessage('Please enter a display name (1–40 characters).', 'error');
    if (!selectedRating) return showMessage('Please choose a star rating first.', 'error');
    if (review.length < 10 || review.length > 600) return showMessage('Your review must be between 10 and 600 characters.', 'error');

    const newReview = {
      id: (typeof crypto !== 'undefined' && crypto.randomUUID) ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      name,
      course: courseInput.value,
      rating: selectedRating,
      review,
      createdAt: Date.now()
    };
    reviews.push(newReview);
    if (!saveReviews()) {
      reviews.pop();
      showMessage('Your browser could not save this review. Check storage settings and try again.', 'error');
      return;
    }

    form.reset();
    charCount.textContent = '0 / 600';
    setRating(0);
    sortSelect.value = 'newest';
    renderSummary();
    renderReviews();
    showMessage('Thanks for sharing your feedback! It is saved in this browser only.', 'success');
  });

  setRating(0);
  renderSummary();
  renderReviews();
})();
